## Packages
framer-motion | Smooth animations for page transitions and interactions
date-fns | Date formatting and manipulation for appointments
react-day-picker | Calendar component for selecting appointment dates

## Notes
Authentication uses Replit Auth blueprint (already installed).
Images will use Unsplash placeholders matching the "barber" aesthetic.
Admin dashboard requires authentication.
Booking flow needs careful state management for the multi-step wizard.
